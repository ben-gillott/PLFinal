CS 4110 Final Project - Alpha
==================

Disclaimer: The majority of this code is currently just my HW6 implementation, along with some tweaks and simplifications in the checker. Most of my progress during this sprint has been in the theory side. 

Type `make` at the command line to build the program. Compilation will produce
an executable file called

Execute a program by typing `./stlc something.stlc`.
There's also a `-nocheck` flag that skips typechecking, which can be useful for running ill-typed programs.
